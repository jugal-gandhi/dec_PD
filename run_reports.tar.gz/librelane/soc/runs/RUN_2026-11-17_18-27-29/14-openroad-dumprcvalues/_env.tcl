set ::env(STEP_ID) OpenROAD.DumpRCValues
set ::env(TECH_LEF) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__nom.tlef
set ::env(MACRO_LEFS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lef/gf180mcu_fd_ip_sram__sram512x8m8wm1.lef /home/runner/work/dec_PD/dec_PD/ip/posit_macro/lef/posit_decoder_32_2.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tl.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tr.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_bl.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_br.lef"
set ::env(STD_CELL_LIBRARY) gf180mcu_fd_sc_mcu7t5v0
set ::env(PAD_CELL_LIBRARY) gf180mcu_fd_io
set ::env(VDD_PIN) VDD
set ::env(GND_PIN) VSS
set ::env(TECH_LEFS) "\"nom_*\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__nom.tlef \"min_*\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__min.tlef \"max_*\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__max.tlef"
set ::env(PRIMARY_GDSII_STREAMOUT_TOOL) klayout
set ::env(DEFAULT_CORNER) nom_tt_025C_5v00
set ::env(STA_CORNERS) "nom_tt_025C_5v00 nom_ss_125C_4v50 nom_ff_n40C_5v50 min_tt_025C_5v00 min_ss_125C_4v50 min_ff_n40C_5v50 max_tt_025C_5v00 max_ss_125C_4v50 max_ff_n40C_5v50"
set ::env(RT_MIN_LAYER) Metal2
set ::env(RT_MAX_LAYER) Metal5
set ::env(SCL_GROUND_PINS) "VSS VPW"
set ::env(SCL_POWER_PINS) "VDD VNW"
set ::env(TRISTATE_CELLS) "\"gf180mcu_fd_sc_mcu7t5v0__bufz*\""
set ::env(FILL_CELLS) "\"gf180mcu_fd_sc_mcu7t5v0__fill_*\""
set ::env(DECAP_CELLS) "\"gf180mcu_fd_sc_mcu7t5v0__fillcap_*\""
set ::env(CELL_LIBS) "\"*_tt_025C_5v00\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lib/gf180mcu_fd_sc_mcu7t5v0__tt_025C_5v00.lib \"*_ff_n40C_5v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lib/gf180mcu_fd_sc_mcu7t5v0__ff_n40C_5v50.lib \"*_ss_125C_4v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lib/gf180mcu_fd_sc_mcu7t5v0__ss_125C_4v50.lib"
set ::env(CELL_LEFS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lef/gf180mcu_fd_sc_mcu7t5v0.lef
set ::env(CELL_GDS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/gds/gf180mcu_fd_sc_mcu7t5v0.gds
set ::env(CELL_VERILOG_MODELS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/verilog/gf180mcu_fd_sc_mcu7t5v0.v
set ::env(CELL_SPICE_MODELS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/spice/gf180mcu_fd_sc_mcu7t5v0.spice
set ::env(CELL_CDLS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/cdl/gf180mcu_fd_sc_mcu7t5v0.cdl
set ::env(SYNTH_EXCLUDED_CELL_FILE) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.tech/librelane/gf180mcu_fd_sc_mcu7t5v0/synth_exclude.cells
set ::env(PNR_EXCLUDED_CELL_FILE) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.tech/librelane/gf180mcu_fd_sc_mcu7t5v0/pnr_exclude.cells
set ::env(OUTPUT_CAP_LOAD) 72.91
set ::env(MAX_FANOUT_CONSTRAINT) 10
set ::env(MAX_TRANSITION_CONSTRAINT) 3.0
set ::env(MAX_CAPACITANCE_CONSTRAINT) 0.2
set ::env(CLOCK_UNCERTAINTY_CONSTRAINT) 0.25
set ::env(CLOCK_TRANSITION_CONSTRAINT) 0.15
set ::env(TIME_DERATING_CONSTRAINT) 5.0
set ::env(IO_DELAY_CONSTRAINT) 10.0
set ::env(SYNTH_DRIVING_CELL) gf180mcu_fd_sc_mcu7t5v0__inv_1/ZN
set ::env(SYNTH_CLK_DRIVING_CELL) gf180mcu_fd_sc_mcu7t5v0__inv_4/ZN
set ::env(SYNTH_TIEHI_CELL) gf180mcu_fd_sc_mcu7t5v0__tieh/Z
set ::env(SYNTH_TIELO_CELL) gf180mcu_fd_sc_mcu7t5v0__tiel/ZN
set ::env(SYNTH_BUFFER_CELL) gf180mcu_fd_sc_mcu7t5v0__buf_1/I/Z
set ::env(PLACE_SITE) GF018hv5v_mcu_sc7
set ::env(CELL_PAD_EXCLUDE) "gf180mcu_fd_sc_mcu7t5v0__filltie \"gf180mcu_fd_sc_mcu7t5v0__fill_*\" gf180mcu_fd_sc_mcu7t5v0__endcap"
set ::env(DIODE_CELL) gf180mcu_fd_sc_mcu7t5v0__antenna/I
set ::env(WELLTAP_CELL) gf180mcu_fd_sc_mcu7t5v0__filltie
set ::env(ENDCAP_CELL) gf180mcu_fd_sc_mcu7t5v0__endcap
set ::env(DESIGN_NAME) soc_chip_top
set ::env(CLOCK_PERIOD) 40.0
set ::env(CLOCK_PORT) clk_PAD
set ::env(CLOCK_NET) pad_clk/Y
set ::env(VDD_NETS) VDD
set ::env(GND_NETS) VSS
set ::env(DIE_AREA) "0.0 0.0 2392.0 2392.0"
set ::env(MACROS) "gf180mcu_fd_ip_sram__sram512x8m8wm1 \"gds /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/gds/gf180mcu_fd_ip_sram__sram512x8m8wm1.gds lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lef/gf180mcu_fd_ip_sram__sram512x8m8wm1.lef instances \\\"u_soc.soc.memory.sram0 \\\\\\\"location \\\\\\\\\\\\\\\"472.0 472.0\\\\\\\\\\\\\\\" orientation FS array None\\\\\\\" u_soc.soc.memory.sram1 \\\\\\\"location \\\\\\\\\\\\\\\"1488.14 472.0\\\\\\\\\\\\\\\" orientation S array None\\\\\\\" u_soc.soc.memory.sram2 \\\\\\\"location \\\\\\\\\\\\\\\"472.0 1435.12\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.soc.memory.sram3 \\\\\\\"location \\\\\\\\\\\\\\\"1488.14 1435.12\\\\\\\\\\\\\\\" orientation FN array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/verilog/gf180mcu_fd_ip_sram__sram512x8m8wm1__blackbox_pp.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lib/gf180mcu_fd_ip_sram__sram512x8m8wm1__tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lib/gf180mcu_fd_ip_sram__sram512x8m8wm1__ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lib/gf180mcu_fd_ip_sram__sram512x8m8wm1__ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" posit_decoder_32_2 \"gds /home/runner/work/dec_PD/dec_PD/ip/posit_macro/gds/posit_decoder_32_2.gds lef /home/runner/work/dec_PD/dec_PD/ip/posit_macro/lef/posit_decoder_32_2.lef instances \\\"u_soc.u_posit \\\\\\\"location \\\\\\\\\\\\\\\"1096.0 1096.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/posit_macro/vh/posit_decoder_32_2.v nl /home/runner/work/dec_PD/dec_PD/ip/posit_macro/nl/posit_decoder_32_2.nl.v pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/posit_macro/lib/posit_decoder_32_2.tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/posit_macro/lib/posit_decoder_32_2.ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/posit_macro/lib/posit_decoder_32_2.ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_tl \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_tl.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tl.lef instances \\\"art_tl \\\\\\\"location \\\\\\\\\\\\\\\"26.0 2222.75\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_tl.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_tl.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_tr \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_tr.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tr.lef instances \\\"art_tr \\\\\\\"location \\\\\\\\\\\\\\\"2222.75 2222.75\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_tr.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_tr.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_bl \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_bl.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_bl.lef instances \\\"art_bl \\\\\\\"location \\\\\\\\\\\\\\\"26.0 26.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_bl.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_bl.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_br \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_br.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_br.lef instances \\\"art_br \\\\\\\"location \\\\\\\\\\\\\\\"2222.75 26.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_br.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_br.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\""
set ::env(FALLBACK_SDC) /home/runner/work/dec_PD/dec_PD/librelane/soc/chip.sdc
set ::env(PAD_LIBS) "\"*_tt_025C_5v00\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__tt_025C_5v00.lib \"*_ff_n40C_5v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ff_n40C_5v50.lib \"*_ss_125C_4v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ss_125C_4v50.lib \"*_tt_025C_3v30\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__tt_025C_3v30.lib \"*_ff_n40C_3v60\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ff_n40C_3v63.lib \"*_ss_125C_3v00\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ss_125C_2v97.lib"
set ::env(PAD_LEFS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__dvdd.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__brk5.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__asig_5p0.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fill1.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fillnc.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__in_c.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fill5.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__brk2.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__bi_24t.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__dvss.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__cor.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fill10.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__in_s.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_ef_io__bi_t.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__bi_t.lef"
set ::env(PAD_GDS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/gds/gf180mcu_fd_io.gds /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/gds/gf180mcu_ef_io.gds"
set ::env(PAD_VERILOG_MODELS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/verilog/gf180mcu_fd_io__blackbox_pp.v /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/verilog/gf180mcu_ef_io__blackbox_pp.v"
set ::env(PAD_SPICE_MODELS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/spice/gf180mcu_fd_io.spice /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/spice/gf180mcu_ef_io.spice"
set ::env(PAD_CDLS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/cdl/gf180mcu_fd_io.cdl
set ::env(PAD_CORNER) gf180mcu_fd_io__cor
set ::env(PAD_FILLERS) "gf180mcu_fd_io__fill10 gf180mcu_fd_io__fill5 gf180mcu_fd_io__fill1 gf180mcu_fd_io__fillnc"
set ::env(PAD_SITE_NAME) GF_IO_Site
set ::env(PAD_CORNER_SITE_NAME) GF_COR_Site
set ::env(PAD_FAKE_SITES) "GF_IO_Site \"0.1 355.0\" GF_COR_Site \"355.0 355.0\""
set ::env(PAD_PLACE_IO_TERMINALS) "gf180mcu_fd_io__asig_5p0/ASIG5V gf180mcu_fd_io__bi_24t/PAD gf180mcu_fd_io__bi_t/PAD gf180mcu_fd_io__in_c/PAD gf180mcu_fd_io__in_s/PAD gf180mcu_fd_io__dvss/DVSS gf180mcu_fd_io__dvdd/DVDD"
set ::env(PAD_EDGE_SPACING) 26.0
set ::env(PAD_ROTATION_HORIZONTAL) R0
set ::env(PAD_ROTATION_VERTICAL) R0
set ::env(PAD_ROTATION_CORNER) R0
set ::env(SET_RC_VERBOSE) 0
set ::env(LAYERS_RC) "\"*\" \"Metal2 \\\"res 0.000225636 cap 0.000135357\\\" Metal3 \\\"res 0.000225636 cap 0.000146141\\\" Metal4 \\\"res 0.000225636 cap 0.000150688\\\" Metal5 \\\"res 0.0000585545 cap 0.000155595\\\"\""
set ::env(VIAS_R) "\"nom_*\" \"Via1 \\\"res 4.5\\\" Via2 \\\"res 4.5\\\" Via3 \\\"res 4.5\\\" Via4 \\\"res 4.5\\\"\" \"min_*\" \"Via1 \\\"res 4.23\\\" Via2 \\\"res 4.23\\\" Via3 \\\"res 4.23\\\" Via4 \\\"res 4.23\\\"\" \"max_*\" \"Via1 \\\"res 16.845\\\" Via2 \\\"res 16.845\\\" Via3 \\\"res 16.845\\\" Via4 \\\"res 16.845\\\"\""
set ::env(SIGNAL_WIRE_RC_LAYERS) "Metal2 Metal3 Metal4"
set ::env(CLOCK_WIRE_RC_LAYERS) "Metal2 Metal3 Metal4"
set ::env(PDN_CONNECT_MACROS_TO_GRID) 1
set ::env(PDN_MACRO_CONNECTIONS) "\"u_soc.soc.memory.sram0 VDD VSS VDD VSS\" \"u_soc.soc.memory.sram1 VDD VSS VDD VSS\" \"u_soc.soc.memory.sram2 VDD VSS VDD VSS\" \"u_soc.soc.memory.sram3 VDD VSS VDD VSS\" \"u_soc.u_posit VDD VSS VDD VSS\""
set ::env(PDN_ENABLE_GLOBAL_CONNECTIONS) 1
set ::env(PNR_SDC_FILE) /home/runner/work/dec_PD/dec_PD/librelane/soc/chip.sdc
set ::env(DEDUPLICATE_CORNERS) 0
set ::env(CURRENT_DEF) /home/runner/work/dec_PD/dec_PD/librelane/soc/runs/RUN_2026-11-17_18-27-29/13-openroad-floorplan/soc_chip_top.def
set ::env(SAVE_ODB) /home/runner/work/dec_PD/dec_PD/librelane/soc/runs/RUN_2026-11-17_18-27-29/14-openroad-dumprcvalues/soc_chip_top.odb
set ::env(SAVE_DEF) /home/runner/work/dec_PD/dec_PD/librelane/soc/runs/RUN_2026-11-17_18-27-29/14-openroad-dumprcvalues/soc_chip_top.def
set ::env(SAVE_SDC) /home/runner/work/dec_PD/dec_PD/librelane/soc/runs/RUN_2026-11-17_18-27-29/14-openroad-dumprcvalues/soc_chip_top.sdc
set ::env(SAVE_NL) /home/runner/work/dec_PD/dec_PD/librelane/soc/runs/RUN_2026-11-17_18-27-29/14-openroad-dumprcvalues/soc_chip_top.nl.v
set ::env(SAVE_PNL) /home/runner/work/dec_PD/dec_PD/librelane/soc/runs/RUN_2026-11-17_18-27-29/14-openroad-dumprcvalues/soc_chip_top.pnl.v
