set ::env(STEP_ID) OpenROAD.ResizerTimingPostCTS
set ::env(TECH_LEF) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__nom.tlef
set ::env(MACRO_LEFS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lef/gf180mcu_fd_ip_sram__sram512x8m8wm1.lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/cpu_core/lef/cpu_core.lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/posit_decoder_32_2/lef/posit_decoder_32_2.lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/dsp_mac/lef/dsp_mac.lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simd_alu/lef/simd_alu.lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/spimemio/lef/spimemio.lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simpleuart/lef/simpleuart.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tl.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tr.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_bl.lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_br.lef"
set ::env(STD_CELL_LIBRARY) gf180mcu_fd_sc_mcu7t5v0
set ::env(PAD_CELL_LIBRARY) gf180mcu_fd_io
set ::env(VDD_PIN) VDD
set ::env(GND_PIN) VSS
set ::env(TECH_LEFS) "\"nom_*\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__nom.tlef \"min_*\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__min.tlef \"max_*\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/techlef/gf180mcu_fd_sc_mcu7t5v0__max.tlef"
set ::env(PRIMARY_GDSII_STREAMOUT_TOOL) klayout
set ::env(DEFAULT_CORNER) nom_tt_025C_5v00
set ::env(STA_CORNERS) "nom_tt_025C_5v00 nom_ss_125C_4v50 nom_ff_n40C_5v50 min_tt_025C_5v00 min_ss_125C_4v50 min_ff_n40C_5v50 max_tt_025C_5v00 max_ss_125C_4v50 max_ff_n40C_5v50"
set ::env(RT_MIN_LAYER) Metal2
set ::env(RT_MAX_LAYER) Metal5
set ::env(SCL_GROUND_PINS) "VSS VPW"
set ::env(SCL_POWER_PINS) "VDD VNW"
set ::env(TRISTATE_CELLS) "\"gf180mcu_fd_sc_mcu7t5v0__bufz*\""
set ::env(FILL_CELLS) "\"gf180mcu_fd_sc_mcu7t5v0__fill_*\""
set ::env(DECAP_CELLS) "\"gf180mcu_fd_sc_mcu7t5v0__fillcap_*\""
set ::env(CELL_LIBS) "\"*_tt_025C_5v00\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lib/gf180mcu_fd_sc_mcu7t5v0__tt_025C_5v00.lib \"*_ff_n40C_5v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lib/gf180mcu_fd_sc_mcu7t5v0__ff_n40C_5v50.lib \"*_ss_125C_4v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lib/gf180mcu_fd_sc_mcu7t5v0__ss_125C_4v50.lib"
set ::env(CELL_LEFS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/lef/gf180mcu_fd_sc_mcu7t5v0.lef
set ::env(CELL_GDS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/gds/gf180mcu_fd_sc_mcu7t5v0.gds
set ::env(CELL_VERILOG_MODELS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/verilog/gf180mcu_fd_sc_mcu7t5v0.v
set ::env(CELL_SPICE_MODELS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/spice/gf180mcu_fd_sc_mcu7t5v0.spice
set ::env(CELL_CDLS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_sc_mcu7t5v0/cdl/gf180mcu_fd_sc_mcu7t5v0.cdl
set ::env(SYNTH_EXCLUDED_CELL_FILE) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.tech/librelane/gf180mcu_fd_sc_mcu7t5v0/synth_exclude.cells
set ::env(PNR_EXCLUDED_CELL_FILE) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.tech/librelane/gf180mcu_fd_sc_mcu7t5v0/pnr_exclude.cells
set ::env(OUTPUT_CAP_LOAD) 72.91
set ::env(MAX_FANOUT_CONSTRAINT) 10
set ::env(MAX_TRANSITION_CONSTRAINT) 3.0
set ::env(MAX_CAPACITANCE_CONSTRAINT) 0.2
set ::env(CLOCK_UNCERTAINTY_CONSTRAINT) 0.25
set ::env(CLOCK_TRANSITION_CONSTRAINT) 0.15
set ::env(TIME_DERATING_CONSTRAINT) 5.0
set ::env(IO_DELAY_CONSTRAINT) 10.0
set ::env(SYNTH_DRIVING_CELL) gf180mcu_fd_sc_mcu7t5v0__inv_1/ZN
set ::env(SYNTH_CLK_DRIVING_CELL) gf180mcu_fd_sc_mcu7t5v0__inv_4/ZN
set ::env(SYNTH_TIEHI_CELL) gf180mcu_fd_sc_mcu7t5v0__tieh/Z
set ::env(SYNTH_TIELO_CELL) gf180mcu_fd_sc_mcu7t5v0__tiel/ZN
set ::env(SYNTH_BUFFER_CELL) gf180mcu_fd_sc_mcu7t5v0__buf_1/I/Z
set ::env(PLACE_SITE) GF018hv5v_mcu_sc7
set ::env(CELL_PAD_EXCLUDE) "gf180mcu_fd_sc_mcu7t5v0__filltie \"gf180mcu_fd_sc_mcu7t5v0__fill_*\" gf180mcu_fd_sc_mcu7t5v0__endcap"
set ::env(DIODE_CELL) gf180mcu_fd_sc_mcu7t5v0__antenna/I
set ::env(WELLTAP_CELL) gf180mcu_fd_sc_mcu7t5v0__filltie
set ::env(ENDCAP_CELL) gf180mcu_fd_sc_mcu7t5v0__endcap
set ::env(DESIGN_NAME) soc3_chip_top
set ::env(CLOCK_PERIOD) 60.0
set ::env(CLOCK_PORT) clk_PAD
set ::env(CLOCK_NET) pad_clk/Y
set ::env(VDD_NETS) VDD
set ::env(GND_NETS) VSS
set ::env(DIE_AREA) "0.0 0.0 3602.0 3602.0"
set ::env(MACROS) "gf180mcu_fd_ip_sram__sram512x8m8wm1 \"gds /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/gds/gf180mcu_fd_ip_sram__sram512x8m8wm1.gds lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lef/gf180mcu_fd_ip_sram__sram512x8m8wm1.lef instances \\\"u_soc.u_ram.sram0 \\\\\\\"location \\\\\\\\\\\\\\\"482.0 726.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_scratch.sram0 \\\\\\\"location \\\\\\\\\\\\\\\"2688.0 726.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_ram.sram1 \\\\\\\"location \\\\\\\\\\\\\\\"482.0 1281.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_scratch.sram1 \\\\\\\"location \\\\\\\\\\\\\\\"2688.0 1281.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_ram.sram2 \\\\\\\"location \\\\\\\\\\\\\\\"482.0 1836.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_scratch.sram2 \\\\\\\"location \\\\\\\\\\\\\\\"2688.0 1836.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_ram.sram3 \\\\\\\"location \\\\\\\\\\\\\\\"482.0 2391.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_scratch.sram3 \\\\\\\"location \\\\\\\\\\\\\\\"2688.0 2391.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/verilog/gf180mcu_fd_ip_sram__sram512x8m8wm1__blackbox_pp.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lib/gf180mcu_fd_ip_sram__sram512x8m8wm1__tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lib/gf180mcu_fd_ip_sram__sram512x8m8wm1__ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_ip_sram/lib/gf180mcu_fd_ip_sram__sram512x8m8wm1__ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" cpu_core \"gds /home/runner/work/dec_PD/dec_PD/ip/v3/macros/cpu_core/gds/cpu_core.gds lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/cpu_core/lef/cpu_core.lef instances \\\"u_soc.u_cpu \\\\\\\"location \\\\\\\\\\\\\\\"1213.0 2171.5\\\\\\\\\\\\\\\" orientation FN array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/v3/vh/cpu_core.v nl /home/runner/work/dec_PD/dec_PD/ip/v3/macros/cpu_core/nl/cpu_core.nl.v pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/cpu_core/lib/cpu_core.tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/cpu_core/lib/cpu_core.ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/cpu_core/lib/cpu_core.ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" posit_decoder_32_2 \"gds /home/runner/work/dec_PD/dec_PD/ip/v3/macros/posit_decoder_32_2/gds/posit_decoder_32_2.gds lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/posit_decoder_32_2/lef/posit_decoder_32_2.lef instances \\\"u_soc.u_posit \\\\\\\"location \\\\\\\\\\\\\\\"2189.0 2600.5\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/posit_macro/vh/posit_decoder_32_2.v nl /home/runner/work/dec_PD/dec_PD/ip/v3/macros/posit_decoder_32_2/nl/posit_decoder_32_2.nl.v pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/posit_decoder_32_2/lib/posit_decoder_32_2.tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/posit_decoder_32_2/lib/posit_decoder_32_2.ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/posit_decoder_32_2/lib/posit_decoder_32_2.ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dsp_mac \"gds /home/runner/work/dec_PD/dec_PD/ip/v3/macros/dsp_mac/gds/dsp_mac.gds lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/dsp_mac/lef/dsp_mac.lef instances \\\"u_soc.u_dsp0 \\\\\\\"location \\\\\\\\\\\\\\\"1210.5 934.5\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_dsp1 \\\\\\\"location \\\\\\\\\\\\\\\"1645.0 934.5\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_dsp2 \\\\\\\"location \\\\\\\\\\\\\\\"1210.5 482.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\" u_soc.u_dsp3 \\\\\\\"location \\\\\\\\\\\\\\\"1645.0 482.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/v3/vh/dsp_mac.v nl /home/runner/work/dec_PD/dec_PD/ip/v3/macros/dsp_mac/nl/dsp_mac.nl.v pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/dsp_mac/lib/dsp_mac.tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/dsp_mac/lib/dsp_mac.ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/dsp_mac/lib/dsp_mac.ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" simd_alu \"gds /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simd_alu/gds/simd_alu.gds lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simd_alu/lef/simd_alu.lef instances \\\"u_soc.u_simd \\\\\\\"location \\\\\\\\\\\\\\\"2079.0 734.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/v3/vh/simd_alu.v nl /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simd_alu/nl/simd_alu.nl.v pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simd_alu/lib/simd_alu.tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simd_alu/lib/simd_alu.ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simd_alu/lib/simd_alu.ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" spimemio \"gds /home/runner/work/dec_PD/dec_PD/ip/v3/macros/spimemio/gds/spimemio.gds lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/spimemio/lef/spimemio.lef instances \\\"u_soc.u_spi \\\\\\\"location \\\\\\\\\\\\\\\"1347.0 1592.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/v3/vh/spimemio.v nl /home/runner/work/dec_PD/dec_PD/ip/v3/macros/spimemio/nl/spimemio.nl.v pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/spimemio/lib/spimemio.tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/spimemio/lib/spimemio.ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/spimemio/lib/spimemio.ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" simpleuart \"gds /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simpleuart/gds/simpleuart.gds lef /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simpleuart/lef/simpleuart.lef instances \\\"u_soc.u_uart \\\\\\\"location \\\\\\\\\\\\\\\"1972.5 1596.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/v3/vh/simpleuart.v nl /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simpleuart/nl/simpleuart.nl.v pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*_tt_025C_5v00\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simpleuart/lib/simpleuart.tt_025C_5v00.lib \\\\\\\"*_ff_n40C_5v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simpleuart/lib/simpleuart.ff_n40C_5v50.lib \\\\\\\"*_ss_125C_4v50\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/v3/macros/simpleuart/lib/simpleuart.ss_125C_4v50.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_tl \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_tl.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tl.lef instances \\\"art_tl \\\\\\\"location \\\\\\\\\\\\\\\"26.0 3432.75\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_tl.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_tl.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_tr \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_tr.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_tr.lef instances \\\"art_tr \\\\\\\"location \\\\\\\\\\\\\\\"3432.75 3432.75\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_tr.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_tr.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_bl \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_bl.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_bl.lef instances \\\"art_bl \\\\\\\"location \\\\\\\\\\\\\\\"26.0 26.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_bl.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_bl.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\" dieart_br \"gds /home/runner/work/dec_PD/dec_PD/ip/dieart/gds/dieart_br.gds lef /home/runner/work/dec_PD/dec_PD/ip/dieart/lef/dieart_br.lef instances \\\"art_br \\\\\\\"location \\\\\\\\\\\\\\\"3432.75 26.0\\\\\\\\\\\\\\\" orientation N array None\\\\\\\"\\\" vh /home/runner/work/dec_PD/dec_PD/ip/dieart/vh/dieart_br.v nl \\\"\\\" pnl \\\"\\\" spef \\\"\\\" lib \\\"\\\\\\\"*\\\\\\\" /home/runner/work/dec_PD/dec_PD/ip/dieart/lib/dieart_br.lib\\\" spice \\\"\\\" sdf \\\"\\\" json_h None\""
set ::env(FALLBACK_SDC) /home/runner/work/dec_PD/dec_PD/librelane/soc3/chip.sdc
set ::env(PAD_LIBS) "\"*_tt_025C_5v00\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__tt_025C_5v00.lib \"*_ff_n40C_5v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ff_n40C_5v50.lib \"*_ss_125C_4v50\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ss_125C_4v50.lib \"*_tt_025C_3v30\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__tt_025C_3v30.lib \"*_ff_n40C_3v60\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ff_n40C_3v63.lib \"*_ss_125C_3v00\" /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lib/gf180mcu_fd_io__ss_125C_2v97.lib"
set ::env(PAD_LEFS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__dvdd.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__brk5.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__asig_5p0.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fill1.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fillnc.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__in_c.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fill5.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__brk2.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__bi_24t.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__dvss.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__cor.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__fill10.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__in_s.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_ef_io__bi_t.lef /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/lef/gf180mcu_fd_io__bi_t.lef"
set ::env(PAD_GDS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/gds/gf180mcu_fd_io.gds /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/gds/gf180mcu_ef_io.gds"
set ::env(PAD_VERILOG_MODELS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/verilog/gf180mcu_fd_io__blackbox_pp.v /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/verilog/gf180mcu_ef_io__blackbox_pp.v"
set ::env(PAD_SPICE_MODELS) "/home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/spice/gf180mcu_fd_io.spice /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/spice/gf180mcu_ef_io.spice"
set ::env(PAD_CDLS) /home/runner/work/dec_PD/dec_PD/pdk/gf180mcuD/libs.ref/gf180mcu_fd_io/cdl/gf180mcu_fd_io.cdl
set ::env(PAD_CORNER) gf180mcu_fd_io__cor
set ::env(PAD_FILLERS) "gf180mcu_fd_io__fill10 gf180mcu_fd_io__fill5 gf180mcu_fd_io__fill1 gf180mcu_fd_io__fillnc"
set ::env(PAD_SITE_NAME) GF_IO_Site
set ::env(PAD_CORNER_SITE_NAME) GF_COR_Site
set ::env(PAD_FAKE_SITES) "GF_IO_Site \"0.1 355.0\" GF_COR_Site \"355.0 355.0\""
set ::env(PAD_PLACE_IO_TERMINALS) "gf180mcu_fd_io__asig_5p0/ASIG5V gf180mcu_fd_io__bi_24t/PAD gf180mcu_fd_io__bi_t/PAD gf180mcu_fd_io__in_c/PAD gf180mcu_fd_io__in_s/PAD gf180mcu_fd_io__dvss/DVSS gf180mcu_fd_io__dvdd/DVDD"
set ::env(PAD_EDGE_SPACING) 26.0
set ::env(PAD_ROTATION_HORIZONTAL) R0
set ::env(PAD_ROTATION_VERTICAL) R0
set ::env(PAD_ROTATION_CORNER) R0
set ::env(SET_RC_VERBOSE) 0
set ::env(LAYERS_RC) "\"*\" \"Metal2 \\\"res 0.000225636 cap 0.000135357\\\" Metal3 \\\"res 0.000225636 cap 0.000146141\\\" Metal4 \\\"res 0.000225636 cap 0.000150688\\\" Metal5 \\\"res 0.0000585545 cap 0.000155595\\\"\""
set ::env(VIAS_R) "\"nom_*\" \"Via1 \\\"res 4.5\\\" Via2 \\\"res 4.5\\\" Via3 \\\"res 4.5\\\" Via4 \\\"res 4.5\\\"\" \"min_*\" \"Via1 \\\"res 4.23\\\" Via2 \\\"res 4.23\\\" Via3 \\\"res 4.23\\\" Via4 \\\"res 4.23\\\"\" \"max_*\" \"Via1 \\\"res 16.845\\\" Via2 \\\"res 16.845\\\" Via3 \\\"res 16.845\\\" Via4 \\\"res 16.845\\\"\""
set ::env(SIGNAL_WIRE_RC_LAYERS) "Metal2 Metal3 Metal4"
set ::env(CLOCK_WIRE_RC_LAYERS) "Metal2 Metal3 Metal4"
set ::env(PDN_CONNECT_MACROS_TO_GRID) 1
set ::env(PDN_MACRO_CONNECTIONS) "\"u_soc.u_ram.sram0 VDD VSS VDD VSS\" \"u_soc.u_scratch.sram0 VDD VSS VDD VSS\" \"u_soc.u_ram.sram1 VDD VSS VDD VSS\" \"u_soc.u_scratch.sram1 VDD VSS VDD VSS\" \"u_soc.u_ram.sram2 VDD VSS VDD VSS\" \"u_soc.u_scratch.sram2 VDD VSS VDD VSS\" \"u_soc.u_ram.sram3 VDD VSS VDD VSS\" \"u_soc.u_scratch.sram3 VDD VSS VDD VSS\" \"u_soc.u_cpu VDD VSS VDD VSS\" \"u_soc.u_posit VDD VSS VDD VSS\" \"u_soc.u_dsp0 VDD VSS VDD VSS\" \"u_soc.u_dsp1 VDD VSS VDD VSS\" \"u_soc.u_dsp2 VDD VSS VDD VSS\" \"u_soc.u_dsp3 VDD VSS VDD VSS\" \"u_soc.u_simd VDD VSS VDD VSS\" \"u_soc.u_spi VDD VSS VDD VSS\" \"u_soc.u_uart VDD VSS VDD VSS\""
set ::env(PDN_ENABLE_GLOBAL_CONNECTIONS) 1
set ::env(PNR_SDC_FILE) /home/runner/work/dec_PD/dec_PD/librelane/soc3/chip.sdc
set ::env(DEDUPLICATE_CORNERS) 0
set ::env(GRT_ADJUSTMENT) 0.299999999999999988897769753748434595763683319091796875
set ::env(GRT_MACRO_EXTENSION) 0
set ::env(GRT_LAYER_ADJUSTMENTS) "0.0 0.0 0.0 0.0 0.0"
set ::env(GRT_ALLOW_CONGESTION) 1
set ::env(GRT_ANTENNA_REPAIR_ITERS) 10
set ::env(GRT_OVERFLOW_ITERS) 50
set ::env(GRT_ANTENNA_REPAIR_MARGIN) 80
set ::env(GRT_ANTENNA_REPAIR_JUMPER_ONLY) 0
set ::env(GRT_ANTENNA_REPAIR_DIODE_ONLY) 0
set ::env(PL_OPTIMIZE_MIRRORING) 1
set ::env(PL_MAX_DISPLACEMENT_X) 500
set ::env(PL_MAX_DISPLACEMENT_Y) 200
set ::env(DPL_CELL_PADDING) 0
set ::env(RSZ_DONT_TOUCH_RX) "\$^"
set ::env(RSZ_CORNERS) "nom_tt_025C_5v00 nom_ss_125C_4v50 nom_ff_n40C_5v50"
set ::env(PL_RESIZER_HOLD_SLACK_MARGIN) 0.35
set ::env(PL_RESIZER_SETUP_SLACK_MARGIN) 0.05000000000000000277555756156289135105907917022705078125
set ::env(PL_RESIZER_HOLD_MAX_BUFFER_PCT) 50.0
set ::env(PL_RESIZER_SETUP_MAX_BUFFER_PCT) 50.0
set ::env(PL_RESIZER_ALLOW_SETUP_VIOS) 0
set ::env(PL_RESIZER_SETUP_GATE_CLONING) 1
set ::env(PL_RESIZER_SETUP_BUFFERING) 1
set ::env(PL_RESIZER_SETUP_BUFFER_REMOVAL) 1
set ::env(PL_RESIZER_FIX_HOLD_FIRST) 0
set ::env(CURRENT_ODB) /home/runner/work/dec_PD/dec_PD/librelane/soc3/runs/RUN_2026-11-18_12-53-35/34-openroad-cts/soc3_chip_top.odb
set ::env(SAVE_ODB) /home/runner/work/dec_PD/dec_PD/librelane/soc3/runs/RUN_2026-11-18_12-53-35/36-openroad-resizertimingpostcts/soc3_chip_top.odb
set ::env(SAVE_DEF) /home/runner/work/dec_PD/dec_PD/librelane/soc3/runs/RUN_2026-11-18_12-53-35/36-openroad-resizertimingpostcts/soc3_chip_top.def
set ::env(SAVE_SDC) /home/runner/work/dec_PD/dec_PD/librelane/soc3/runs/RUN_2026-11-18_12-53-35/36-openroad-resizertimingpostcts/soc3_chip_top.sdc
set ::env(SAVE_NL) /home/runner/work/dec_PD/dec_PD/librelane/soc3/runs/RUN_2026-11-18_12-53-35/36-openroad-resizertimingpostcts/soc3_chip_top.nl.v
set ::env(SAVE_PNL) /home/runner/work/dec_PD/dec_PD/librelane/soc3/runs/RUN_2026-11-18_12-53-35/36-openroad-resizertimingpostcts/soc3_chip_top.pnl.v
